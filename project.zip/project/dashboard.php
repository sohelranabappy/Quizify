<?php
require_once 'database.php'; 
session_start(); 

if (!isset($_SESSION['admin_key']) || $_SESSION['admin_key'] !== 'admin_logged_in') {
    header("location: admin.php");
    exit;
}

$admin_name = htmlspecialchars($_SESSION['admin_name']); 
$admin_email = htmlspecialchars($_SESSION['admin_email']); 

$q = isset($_GET['q']) ? (int)$_GET['q'] : 0; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <title>Quizify | Admin Dashboard</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"> 
    <link rel="stylesheet" href="style.css"> 
</head>
<body class="bg"> <nav class="navbar navbar-expand-lg navbar-light  shadow-sm sticky-top"> 
        <div class="container">
            <a class="logo-font" href="dashboard.php?q=0"><h2>Quizify</h2></a> 
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAdmin" aria-controls="navbarNavAdmin" aria-expanded="false" aria-label="Toggle navigation"> 
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAdmin"> 
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($q == 0) ? 'active' : ''; ?>" href="dashboard.php?q=0"><i class="bi bi-house-door-fill"></i> Home</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($q == 1) ? 'active' : ''; ?>" href="dashboard.php?q=1"><i class="bi bi-people-fill"></i> Users</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($q == 2) ? 'active' : ''; ?>" href="dashboard.php?q=2"><i class="bi bi-trophy-fill"></i> Ranking</a> 
                    </li>
                    <li class="nav-item dropdown <?php echo ($q == 4 || $q == 5) ? 'active' : ''; ?>"> 
                         <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownQuiz" role="button" data-bs-toggle="dropdown" aria-expanded="false"> 
                           <i class="bi bi-pencil-square"></i> Quiz
                         </a>
                         <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownQuiz"> 
                             <li><a class="dropdown-item <?php echo ($q == 4) ? 'active' : ''; ?>" href="dashboard.php?q=4"><i class="bi bi-plus-circle-fill"></i> Add Quiz</a></li> 
                             <li><a class="dropdown-item <?php echo ($q == 5) ? 'active' : ''; ?>" href="dashboard.php?q=5"><i class="bi bi-trash-fill"></i> Remove Quiz</a></li> 
                         </ul>
                    </li>
                    
                </ul>
                <ul class="navbar-nav"> 
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownUserAdmin" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> <?php echo $admin_name; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end" aria-labelledby="navbarDropdownUserAdmin"> 
                            <li><a class="dropdown-item" href="logout_admin.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li> 
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">

                 <?php
                 if (isset($_GET['deleted']) && $_GET['deleted'] == 1) { echo '<div class="alert alert-success alert-dismissible fade show" role="alert">User deleted successfully.<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>'; } 
                 if (isset($_GET['removed']) && $_GET['removed'] == 1) { echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Quiz removed successfully.<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>'; } 
                 if (isset($_GET['quiz_added']) && $_GET['quiz_added'] == 1) { echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Quiz and questions added successfully.<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>'; } 
                 if (isset($_GET['error'])) { 
                     $errMsg = 'An unknown error occurred.';
                     if ($_GET['error'] == 1) $errMsg = 'Error removing quiz.'; 
                     if ($_GET['error'] == 'add_details') $errMsg = 'Error saving quiz details. Please check input.';
                     if ($_GET['error'] == 'invalid_input') $errMsg = 'Invalid input provided for quiz details.';
                     if ($_GET['error'] == 'add_qns') {
                         $errMsg = 'Error adding questions. Please check all fields.';
                         if(isset($_SESSION['add_question_error'])) { 
                             $errMsg .= ' Details: ' . htmlspecialchars($_SESSION['add_question_error']);
                             unset($_SESSION['add_question_error']); 
                         }
                     }
                     echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">' . $errMsg . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
                 }

                  echo '<script> if (window.history.replaceState) { let url = new URL(window.location.href); url.searchParams.delete("deleted"); url.searchParams.delete("removed"); url.searchParams.delete("quiz_added"); url.searchParams.delete("error"); window.history.replaceState({path: url.href}, "", url.href); } </script>';

                 if ($q == 0) {
                     echo '<div class="card panel">';
                     echo '<div class="card-header panel-title">Admin Dashboard</div>';
                     echo '<div class="card-body panel-body">';
                     echo '<h4>Welcome, ' . $admin_name . '!</h4>';
                     echo '<p>Use the navigation bar above to manage users, quizzes, and view rankings.</p>';
                     echo '</div></div>';
                 }

                 elseif ($q == 1) {
                     echo '<div class="card panel">';
                     echo '<div class="card-header panel-title"><i class="bi bi-people-fill"></i> User List</div>';
                     echo '<div class="card-body panel-body">';

                     $result_users = $con->query("SELECT name, email, university FROM `user` ORDER BY name ASC") or die('Error fetching users: ' . $con->error); 
                     if ($result_users->num_rows > 0) { 
                         echo '<div class="table-responsive">';
                         echo '<table class="table table-striped table-hover">'; 
                         echo '<thead><tr><th>#</th><th>Name</th><th>University</th><th>Email</th><th>Action</th></tr></thead>';
                         echo '<tbody>';
                         $c = 1;
                         while ($row = $result_users->fetch_assoc()) { 
                             $name = htmlspecialchars($row['name']);
                             $email = htmlspecialchars($row['email']);
                             $university = htmlspecialchars($row['university'] ?? 'N/A'); 
                             echo '<tr>';
                             echo '<td>' . $c++ . '</td>';
                             echo '<td>' . $name . '</td>';
                             echo '<td>' . $university . '</td>';
                             echo '<td>' . $email . '</td>';
                             echo '<td><a href="update.php?q=duser&demail=' . urlencode($email) . '" class="btn btn-danger btn-sm" title="Delete User" onclick="return confirm(\'Are you sure you want to delete user \\\'' . addslashes($name) . '\\\' (' . addslashes($email) . ') and all related data (history, ranking)? This cannot be undone.\');"><i class="bi bi-trash-fill"></i> Delete</a></td>';
                             echo '</tr>';
                         }
                         echo '</tbody></table></div>';
                     } else {
                         echo '<p class="text-center text-muted">No users found.</p>'; 
                     }
                     echo '</div></div>';
                     $result_users->free();
                 }

                 elseif ($q == 2) {
                     echo '<div class="card panel">';
                     echo '<div class="card-header panel-title"><i class="bi bi-trophy-fill"></i> User Rankings</div>';
                     echo '<div class="card-body panel-body">';

                     $result_rank = $con->query("SELECT r.email, r.score, u.name FROM `rank` r JOIN `user` u ON r.email = u.email ORDER BY r.score DESC, r.time ASC") or die('Error fetching ranking: ' . $con->error); 

                     if ($result_rank->num_rows > 0) { 
                         echo '<div class="table-responsive">';
                         echo '<table class="table table-striped table-hover ranking-table">'; 
                         echo '<thead><tr><th>Rank</th><th>Name</th><th>Email</th><th>Score</th></tr></thead>';
                         echo '<tbody>';
                         $c = 1;
                         while ($row_rank = $result_rank->fetch_assoc()) { 
                             $rank_num = $c++;
                             $name = htmlspecialchars($row_rank['name']);
                             $email = htmlspecialchars($row_rank['email']);
                             $score = htmlspecialchars($row_rank['score']);
                             echo '<tr>';  
                             echo '<td><span class="rank-badge">' . $rank_num . '</span></td>';
                             echo '<td>' . $name . '</td>';
                             echo '<td>' . $email . '</td>';
                             echo '<td>' . $score . '</td>';
                             echo '</tr>';
                         }
                         echo '</tbody></table></div>';
                     } else {
                         echo '<p class="text-center text-muted">No ranking data available yet.</p>'; 
                     }
                     echo '</div></div>';
                     $result_rank->free();
                 }

                  elseif ($q == 4 && !isset($_GET['step'])) {
                     echo '<div class="row justify-content-center">';
                     echo '<div class="col-md-8 col-lg-6">';
                     echo '<div class="card panel">'; 
                     echo '<div class="card-header panel-title text-center"><i class="bi bi-plus-circle-fill"></i> Enter Quiz Details</div>';
                     echo '<div class="card-body panel-body">';
                     echo '<form class="form-horizontal" name="form" action="update.php?q=addquiz" method="POST">'; 
                     echo '<fieldset>';
                     echo '<div class="mb-3"><label class="form-label" for="name">Quiz Title</label><input id="name" name="name" placeholder="Enter Quiz Title" class="form-control" type="text" required></div>';
                     echo '<div class="mb-3"><label class="form-label" for="total">Total Number of Questions</label><input id="total" name="total" placeholder="Enter total number of questions" class="form-control" type="number" min="1" required></div>';
                     echo '<div class="mb-3"><label class="form-label" for="right">Marks for Correct Answer</label><input id="right" name="right" placeholder="Enter marks for correct answer" class="form-control" type="number" min="0" value="1" required></div>'; 
                     echo '<div class="mb-3"><label class="form-label" for="wrong">Marks Deducted for Wrong Answer</label><input id="wrong" name="wrong" placeholder="Enter POSITIVE marks to deduct (e.g., 1 or 0)" class="form-control" type="number" min="0" value="0" required></div>';
                     echo '<div class="mb-3 text-center"><button type="submit" class="btn btn-primary"><i class="bi bi-arrow-right-circle"></i> Submit & Add Questions</button></div>';
                     echo '</fieldset>';
                     echo '</form>';
                     echo '</div></div></div></div>';
                 }

                 elseif ($q == 4 && isset($_GET['step']) && $_GET['step'] == 2 && isset($_GET['eid']) && isset($_GET['n'])) {
                     $eid = htmlspecialchars($_GET['eid']);
                     $n = (int)$_GET['n']; 
                     if ($n <= 0) {
                         echo '<div class="alert alert-danger">Invalid number of questions specified.</div>';
                     } else {
                         echo '<div class="row justify-content-center">';
                         echo '<div class="col-md-10 col-lg-9">';
                         echo '<div class="card panel">'; 
                         echo '<div class="card-header panel-title text-center"><i class="bi bi-list-ol"></i> Enter Question Details (Quiz ID: ' . $eid . ')</div>'; 
                         echo '<div class="card-body panel-body">';
                         echo '<form class="form-horizontal" name="form" action="update.php?q=addqns&n=' . $n . '&eid=' . $eid . '&ch=4" method="POST">'; 
                         echo '<fieldset>';

                         for ($i = 1; $i <= $n; $i++) { 
                             echo '<div class="mb-4 p-3 border rounded bg-light question-input-group">'; 
                             echo '<h5>Question ' . $i . ':</h5>'; 
                             echo '<div class="mb-3"><label class="form-label" for="qns' . $i . '">Question Text:</label><textarea rows="3" id="qns' . $i . '" name="qns' . $i . '" class="form-control" placeholder="Write question ' . $i . ' here..." required></textarea></div>';
                             echo '<div class="row">';
                             $options_letters = ['A', 'B', 'C', 'D'];
                             for ($j = 1; $j <= 4; $j++) {
                                 echo '<div class="col-md-6 mb-2">';
                                 echo '<label class="form-label" for="' . $i . $j . '">Option ' . $options_letters[$j-1] . ':</label>';
                                 echo '<input id="' . $i . $j . '" name="' . $i . $j . '" placeholder="Enter option ' . $options_letters[$j-1] . '" class="form-control" type="text" required>';
                                 echo '</div>';
                             }
                             echo '</div>'; 
                             echo '<div class="mt-2"><label class="form-label" for="ans' . $i . '">Correct Answer:</label><select id="ans' . $i . '" name="ans' . $i . '" class="form-select" required>'; 
                             echo '<option value="" disabled selected>-- Select Correct Answer for Question ' . $i . ' --</option>'; 
                             echo '<option value="a">Option A</option>'; 
                             echo '<option value="b">Option B</option>'; 
                             echo '<option value="c">Option C</option>'; 
                             echo '<option value="d">Option D</option>'; 
                             echo '</select></div>';
                             echo '</div>'; 
                         }

                         echo '<div class="mb-3 text-center mt-4"><button type="submit" class="btn btn-success btn-lg"><i class="bi bi-check-circle-fill"></i> Submit All Questions</button></div>'; 
                         echo '</fieldset>';
                         echo '</form>';
                         echo '</div></div></div></div>';
                     }
                 }

                  elseif ($q == 5) {
                     echo '<div class="card panel">';
                     echo '<div class="card-header panel-title"><i class="bi bi-trash-fill"></i> Remove Quiz</div>'; 
                     echo '<div class="card-body panel-body">'; 

                     $result_quiz = $con->query("SELECT eid, title, total, sahi FROM `quiz` ORDER BY date DESC") or die('Error fetching quizzes: ' . $con->error); 
                     if ($result_quiz->num_rows > 0) { 
                         echo '<div class="table-responsive">';
                         echo '<table class="table table-striped table-hover">'; 
                         echo '<thead><tr><th>#</th><th>Topic</th><th>Questions</th><th>Max Marks</th><th>Action</th></tr></thead>';
                         echo '<tbody>';
                         $c = 1;
                         while ($row_quiz = $result_quiz->fetch_assoc()) { 
                             $eid = htmlspecialchars($row_quiz['eid']);
                             $title = htmlspecialchars($row_quiz['title']);
                             $total = (int)$row_quiz['total']; 
                             $sahi = (int)$row_quiz['sahi']; 
                             $total_marks = $total * $sahi; 
                             echo '<tr>'; 
                             echo '<td>' . $c++ . '</td>';
                             echo '<td>' . $title . '</td>';
                             echo '<td>' . $total . '</td>';
                             echo '<td>' . $total_marks . '</td>';
                             
                              echo '<td><a href="update.php?q=rmquiz&eid=' . urlencode($eid) . '" class="btn btn-danger btn-sm" title="Remove Quiz" onclick="return confirm(\'Are you sure you want to remove quiz \\\'' . addslashes($title) . '\\\' and ALL its questions, history, etc.? This cannot be undone.\');"><i class="bi bi-trash-fill"></i> Remove</a></td>';
                             echo '</tr>';
                         }
                         echo '</tbody></table></div>'; 
                     } else {
                         echo '<p class="text-center text-muted">No quizzes found to remove.</p>';
                     }
                     echo '</div></div>';
                     $result_quiz->free();
                 }
                ?>

            </div> </div> </div> <footer class="footer mt-auto">
        <div class="container text-center">
            <span>Admin Panel &copy; <?php echo date("Y"); ?></span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
<?php $con->close();