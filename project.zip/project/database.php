<?php
$dbHost = 'localhost'; 
$dbUsername = 'root';  
$dbPassword = '';     
$dbName = 'quiz'; 

$con = new mysqli($dbHost, $dbUsername, $dbPassword);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sqlCreateDb = "CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($con->query($sqlCreateDb) === FALSE) {
    die("Error creating database: " . $con->error);
}

$con->select_db($dbName);

$sqlUserTable = "CREATE TABLE IF NOT EXISTS `user` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL, 
    `university` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlUserTable) === FALSE) {
    die("Error creating table 'user': " . $con->error);
}

$sqlAdminTable = "CREATE TABLE IF NOT EXISTS `admin` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(255) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlAdminTable) === FALSE) { 
    die("Error creating table 'admin': " . $con->error);
}

$adminEmail = 'admin@email.com'; 
$adminPassword = 'admin'; 

$checkAdmin = $con->query("SELECT id FROM `admin` WHERE email='$adminEmail'");
if ($checkAdmin && $checkAdmin->num_rows == 0) { 
    $stmtAdmin = $con->prepare("INSERT INTO `admin` (email, password) VALUES (?, ?)");
    if ($stmtAdmin) {
        $stmtAdmin->bind_param("ss", $adminEmail, $adminPassword);
        $stmtAdmin->execute();
        $stmtAdmin->close();
    }
}
if ($checkAdmin) {
    $checkAdmin->free();
}

$sqlQuizTable = "CREATE TABLE IF NOT EXISTS `quiz` (
    `eid` VARCHAR(50) PRIMARY KEY, 
    `title` VARCHAR(255) NOT NULL,
    `sahi` INT NOT NULL DEFAULT 1, 
    `wrong` INT NOT NULL DEFAULT 0, 
    `total` INT NOT NULL, 
    `date` DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlQuizTable) === FALSE) { 
    die("Error creating table 'quiz': " . $con->error);
}

$sqlQuestionsTable = "CREATE TABLE IF NOT EXISTS `questions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `eid` VARCHAR(50) NOT NULL, 
    `qid` VARCHAR(50) UNIQUE NOT NULL, 
    `qns` TEXT NOT NULL, 
    `choice` INT NOT NULL DEFAULT 4, 
    `sn` INT NOT NULL, 
    FOREIGN KEY (`eid`) REFERENCES `quiz`(`eid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlQuestionsTable) === FALSE) { 
    die("Error creating table 'questions': " . $con->error);
}

$sqlOptionsTable = "CREATE TABLE IF NOT EXISTS `options` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `qid` VARCHAR(50) NOT NULL, 
    `option` TEXT NOT NULL, 
    `optionid` VARCHAR(50) UNIQUE NOT NULL, 
    FOREIGN KEY (`qid`) REFERENCES `questions`(`qid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlOptionsTable) === FALSE) { 
    die("Error creating table 'options': " . $con->error);
}

$sqlAnswerTable = "CREATE TABLE IF NOT EXISTS `answer` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `qid` VARCHAR(50) NOT NULL,
    `ansid` VARCHAR(50) NOT NULL,
    FOREIGN KEY (`qid`) REFERENCES `questions`(`qid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`ansid`) REFERENCES `options`(`optionid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlAnswerTable) === FALSE) { 
    die("Error creating table 'answer': " . $con->error);
}

$sqlHistoryTable = "CREATE TABLE IF NOT EXISTS `history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(255) NOT NULL, 
    `eid` VARCHAR(50) NOT NULL, 
    `score` INT NOT NULL DEFAULT 0,
    `level` INT NOT NULL DEFAULT 0, 
    `sahi` INT NOT NULL DEFAULT 0, 
    `wrong` INT NOT NULL DEFAULT 0, 
    `date` DATETIME NOT NULL,
    FOREIGN KEY (`email`) REFERENCES `user`(`email`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`eid`) REFERENCES `quiz`(`eid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlHistoryTable) === FALSE) {
    die("Error creating table 'history': " . $con->error);
}

$sqlRankTable = "CREATE TABLE IF NOT EXISTS `rank` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(255) UNIQUE NOT NULL, 
    `score` INT NOT NULL DEFAULT 0,
    `time` DATETIME NOT NULL, 
    FOREIGN KEY (`email`) REFERENCES `user`(`email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($con->query($sqlRankTable) === FALSE) {
    die("Error creating table 'rank': " . $con->error);
}

$con->set_charset("utf8mb4");
?>