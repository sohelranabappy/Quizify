<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Quizify</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> 
    <link rel="stylesheet" href="style.css"> 
</head>
<body class="index-bg"> 

    <div class="container">
        <div class="row min-vh-100 justify-content-center align-items-center">
            <div class="col-md-6 text-center intro-box"> 
                <h1 class="logo-font mb-4">Quizify</h1> 
                <p class="lead mb-4">Test your knowledge!</p>
                <div>
                    <a href="login.php" class="btn btn-primary btn-lg me-2" id="btn">Login</a>
                    <a href="register.php" class="btn btn-success btn-lg">Register</a> 
                </div>
                 <div class="mt-4">
                     <a href="admin.php" class="text-secondary small">Admin Login</a>
                 </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>