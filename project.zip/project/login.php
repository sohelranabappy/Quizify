<?php
require_once 'database.php'; 
session_start(); 

if (isset($_SESSION["user_email"])) {
    header("location: welcome.php?q=1");
    exit;
}
if (isset($_SESSION["admin_email"])) {
    header("location: dashboard.php?q=0");
    exit;
}

$error_message = ''; 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $email = trim($_POST['email']); 
    $password_attempt = trim($_POST['password']); 

    if (!empty($email) && !empty($password_attempt)) { 
        $stmt = $con->prepare("SELECT id, name, email, password FROM `user` WHERE email = ?"); 
        $stmt->bind_param("s", $email); 
        $stmt->execute(); 
        $result = $stmt->get_result(); 

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            if ($password_attempt == $user['password']) {
                session_regenerate_id(true);
                $_SESSION["user_name"] = $user['name'];
                $_SESSION["user_id"] = $user['id'];
                $_SESSION["user_email"] = $user['email'];
                header("location: welcome.php?q=1"); 
                exit;
            } else {
                $error_message = "Invalid email or password."; 
            }
        } else {
            $error_message = "Invalid email or password."; 
        }
        $stmt->close(); 
    } else {
        $error_message = "Please enter both email and password."; 
    }
}
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quizify | Login </title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> 
    <link rel="stylesheet" href="style.css"> 
</head>
<body class="form-bg"> 

    <div class="container">
        <div class="row min-vh-100 justify-content-center align-items-center">
            <div class="col-md-6 col-lg-4">
                 <div class="form-container p-4 p-sm-5"> 
                    <div class="text-center mb-4">
                         <h2 class="logo-font">Quizify</h2><br>
                         <p class="text-muted">Login to access your account</p>
                    </div>

                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div> 
                    <?php endif; ?>

                    <form method="post" action="login.php" id="loginForm" novalidate> 
                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" name="email" id="email" class="form-control" required>
                            <div class="invalid-feedback">Please enter your email.</div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                            <div class="invalid-feedback">Please enter your password.</div>
                        </div>
                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-primary" name="submit">Login</button>
                        </div>
                        <div class="text-center">
                            <span class="text-muted">Don't have an account?</span> <a href="register.php">Register Here</a>
                             <br> <a href="admin.php" class="text-secondary small mt-2 d-block">Admin Login</a>
                        </div>
                    </form>
                 </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script> 
     <script src="validation.js"></script>
</body>
</html>