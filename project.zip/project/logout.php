<?php
session_start();

unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
unset($_SESSION['user_email']);
session_regenerate_id(true);

header("Location: login.php?logged_out=1"); 
exit;
?>