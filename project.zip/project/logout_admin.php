<?php
session_start();

unset($_SESSION['admin_key']);
unset($_SESSION['admin_name']);
unset($_SESSION['admin_email']); 

session_regenerate_id(true);

header("Location: admin.php?logged_out=1");
exit;
?>