<?php
require_once 'database.php';
session_start(); 

$isAdmin = isset($_SESSION['admin_key']) && $_SESSION['admin_key'] === 'admin_logged_in';
$isUser = isset($_SESSION['user_email']);
$user_email = $isUser ? $_SESSION['user_email'] : null;


$action = isset($_GET['q']) ? $_GET['q'] : null;

if ($isUser) {

    if ($action == 'quiz' && isset($_GET['step']) && $_GET['step'] == 2 && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_GET['eid'], $_GET['n'], $_GET['t'], $_GET['qid'], $_POST['ans'])) {
            header("location: welcome.php?q=1&error=processing");
            exit;
        }

        $eid = $_GET['eid']; 
        $sn = (int)$_GET['n'];
        $total = (int)$_GET['t'];
        $qid = $_GET['qid'];
        $selected_ans_id = $_POST['ans'];

        $con->begin_transaction();
        try {
            $correct_ans_id = null;
            $sahi = 0;
            $wrong = 0;

            $stmt_ans_check = $con->prepare("SELECT ansid FROM `answer` WHERE qid = ?");
            $stmt_ans_check->bind_param("s", $qid); 
            $stmt_ans_check->execute(); 
            $res_ans_check = $stmt_ans_check->get_result(); 
            if ($res_ans_check->num_rows == 1) {
                $correct_ans_id = $res_ans_check->fetch_assoc()['ansid']; 
            }
            $stmt_ans_check->close(); 

            $stmt_quiz_rules = $con->prepare("SELECT sahi, wrong FROM `quiz` WHERE eid = ?");
            $stmt_quiz_rules->bind_param("s", $eid); 
            $stmt_quiz_rules->execute(); 
            $res_quiz_rules = $stmt_quiz_rules->get_result(); 
            if ($res_quiz_rules->num_rows == 1) { 
                $rules = $res_quiz_rules->fetch_assoc(); 
                $sahi = (int)$rules['sahi']; 
                $wrong = (int)$rules['wrong']; 
            }
            $stmt_quiz_rules->close(); 

            if ($correct_ans_id === null) { 
                throw new Exception("Could not find answer for question ID $qid.");
            }


            $is_correct = ($selected_ans_id == $correct_ans_id); 
            $score_change = $is_correct ? $sahi : -$wrong; 
            $sahi_increment = $is_correct ? 1 : 0; 
            $wrong_increment = !$is_correct ? 1 : 0; 

            $history_exists = false;
            $stmt_check_hist = $con->prepare("SELECT id FROM `history` WHERE email = ? AND eid = ?");
            $stmt_check_hist->bind_param("ss", $user_email, $eid);
            $stmt_check_hist->execute();
            if ($stmt_check_hist->get_result()->num_rows > 0) {
                $history_exists = true;
            }
            $stmt_check_hist->close();

            if (!$history_exists && $sn == 1) {
                 $stmt_insert_hist = $con->prepare("INSERT INTO `history` (email, eid, score, level, sahi, wrong, date) VALUES (?, ?, 0, 0, 0, 0, NOW())");
                 $stmt_insert_hist->bind_param("ss", $user_email, $eid);
                 if (!$stmt_insert_hist->execute()) { 
                     throw new Exception("Error inserting initial history: " . $stmt_insert_hist->error);
                 }
                 $stmt_insert_hist->close();
                 $history_exists = true;
             } elseif (!$history_exists && $sn != 1) {
                 throw new Exception("History not found for subsequent question.");
             }

            $stmt_update_hist = $con->prepare("UPDATE `history` SET score = score + ?, level = ?, sahi = sahi + ?, wrong = wrong + ?, date = NOW() WHERE email = ? AND eid = ?");
            $stmt_update_hist->bind_param("iiiiss", $score_change, $sn, $sahi_increment, $wrong_increment, $user_email, $eid);
            if (!$stmt_update_hist->execute()) {
                throw new Exception("Error updating history: " . $stmt_update_hist->error);
            }
            $stmt_update_hist->close();

            $con->commit();

            if ($sn < $total) {
                $next_sn = $sn + 1;
                header("location:welcome.php?q=quiz&step=2&eid=$eid&n=$next_sn&t=$total");
            } else {
                try {
                    $final_score = 0;
                    $stmt_get_score = $con->prepare("SELECT score FROM `history` WHERE email = ? AND eid = ?");
                    $stmt_get_score->bind_param("ss", $user_email, $eid);
                    $stmt_get_score->execute();
                    $res_score = $stmt_get_score->get_result();
                    if ($res_score->num_rows == 1) {
                        $final_score = (int)$res_score->fetch_assoc()['score'];
                    }
                    $stmt_get_score->close();

                    $stmt_rank_upsert = $con->prepare("INSERT INTO `rank` (email, score, time) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE score = score + VALUES(score), time = NOW()");

                     $current_rank_score = 0;
                     $stmt_get_rank = $con->prepare("SELECT score FROM `rank` WHERE email = ?");
                     $stmt_get_rank->bind_param("s", $user_email);
                     $stmt_get_rank->execute();
                     $res_rank = $stmt_get_rank->get_result();
                     if($res_rank->num_rows == 1) {
                         $current_rank_score = (int)$res_rank->fetch_assoc()['score'];
                     }
                     $stmt_get_rank->close();
                     $new_total_score = $current_rank_score + $final_score;

                     $stmt_rank_upsert = $con->prepare("INSERT INTO `rank` (email, score, time) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE score = VALUES(score), time = NOW()");
                     $stmt_rank_upsert->bind_param("si", $user_email, $new_total_score);

                    if (!$stmt_rank_upsert->execute()) {
                        throw new Exception("Error updating rank: " . $stmt_rank_upsert->error);
                    }
                    $stmt_rank_upsert->close();

                    header("location:welcome.php?q=result&eid=$eid");

                } catch (Exception $rank_e) {
                    error_log("Error updating rank for user $user_email after quiz $eid: " . $rank_e->getMessage());
                    header("location:welcome.php?q=result&eid=$eid&rank_error=1");
                }
            }
            exit;

        } catch (Exception $e) {
            $con->rollback();
            error_log("Error processing answer for user $user_email, quiz $eid, question $sn: " . $e->getMessage());
            header("location:welcome.php?q=quiz&step=2&eid=$eid&n=$sn&t=$total&error=processing");
            exit;
        }
    }
    elseif ($action == 'quizre' && isset($_GET['step']) && $_GET['step'] == 25 && isset($_GET['eid'])) {
        $eid = $_GET['eid'];
        $total = isset($_GET['t']) ? (int)$_GET['t'] : 0;

        $con->begin_transaction();
        try {
            $score_to_deduct = 0;
            $stmt_get_hist_score = $con->prepare("SELECT score FROM `history` WHERE email = ? AND eid = ?");
            $stmt_get_hist_score->bind_param("ss", $user_email, $eid);
            $stmt_get_hist_score->execute(); 
            $res_hist_score = $stmt_get_hist_score->get_result(); 
            if ($res_hist_score->num_rows == 1) {
                $score_to_deduct = (int)$res_hist_score->fetch_assoc()['score'];
            }
            $stmt_get_hist_score->close();

            $stmt_del_hist = $con->prepare("DELETE FROM `history` WHERE email = ? AND eid = ?");
            $stmt_del_hist->bind_param("ss", $user_email, $eid); 
            if (!$stmt_del_hist->execute()) { 
                throw new Exception("Error deleting history: " . $stmt_del_hist->error);
            }
            $deleted_rows = $stmt_del_hist->affected_rows;
            $stmt_del_hist->close(); 

            if ($deleted_rows > 0 && $score_to_deduct != 0) {
                $stmt_update_rank = $con->prepare("UPDATE `rank` SET score = score - ?, time = NOW() WHERE email = ?");
                $stmt_update_rank->bind_param("is", $score_to_deduct, $user_email); 
                if (!$stmt_update_rank->execute()) { 
                    error_log("Error updating rank during restart for user $user_email, quiz $eid: " . $stmt_update_rank->error); 
                }
                $stmt_update_rank->close();
            }

            $con->commit();

            if ($total <= 0) {
                $stmt_get_total = $con->prepare("SELECT total FROM `quiz` WHERE eid = ?");
                $stmt_get_total->bind_param("s", $eid); 
                $stmt_get_total->execute(); 
                $res_total = $stmt_get_total->get_result(); 
                if ($res_total->num_rows == 1) {
                    $total = (int)$res_total->fetch_assoc()['total']; 
                }
                $stmt_get_total->close(); 
            }

            if ($total > 0) {
                header("location:welcome.php?q=quiz&step=2&eid=$eid&n=1&t=$total"); 
            } else {
                header("location:welcome.php?q=1&error=restart_failed");
            }
            exit;

        } catch (Exception $e) {
            $con->rollback();
            error_log("Error restarting quiz for user $user_email, quiz $eid: " . $e->getMessage());
            header("location:welcome.php?q=1&error=restart_failed");
            exit;
        }
    }

}
elseif ($isAdmin) {

    if ($action == 'duser' && isset($_GET['demail'])) {
        $demail = $_GET['demail'];
        if ($demail == $_SESSION['admin_email']) {
             header("location:dashboard.php?q=1&error=self_delete");
             exit;
        }

        $con->begin_transaction();
        try {
            $stmt_rank = $con->prepare("DELETE FROM `rank` WHERE email = ?");
            $stmt_history = $con->prepare("DELETE FROM `history` WHERE email = ?");
            $stmt_user = $con->prepare("DELETE FROM `user` WHERE email = ?");

            $stmt_rank->bind_param("s", $demail);
            $stmt_history->bind_param("s", $demail);
            $stmt_user->bind_param("s", $demail);

            $stmt_rank->execute();
            $stmt_history->execute(); 
            $stmt_user->execute(); 

            if ($stmt_user->affected_rows > 0) {
                $con->commit(); /* source: 99 */
            } else {
                // User might not exist or already deleted, commit anyway or rollback based on policy
                $con->commit(); // Commit even if user not found (rank/history might be cleaned) /* source: 100, 101 */
            }

            $stmt_rank->close(); /* source: 101 */
            $stmt_history->close(); /* source: 102 */
            $stmt_user->close(); /* source: 102 */

        } catch (mysqli_sql_exception $exception) { /* source: 102 */
            $con->rollback(); /* source: 102 */
            // Log the error instead of dying in production
             error_log("Error deleting user ($demail): " . $exception->getMessage());
             header("location:dashboard.php?q=1&error=delete_failed"); // Add feedback parameter
            exit;
             // die("Error deleting user: " . $exception->getMessage()); // Source: 102
        }
        header("location:dashboard.php?q=1&deleted=1"); // Add feedback parameter /* source: 103 */
        exit;
    }

    // --- Remove Quiz (q=rmquiz) --- /* source: 103 */
    if ($action == 'rmquiz' && isset($_GET['eid'])) {
        $eid = $_GET['eid']; /* source: 103 */
        $con->begin_transaction(); /* source: 104 */
        try {
             $stmt_hist = $con->prepare("DELETE FROM `history` WHERE eid = ?");
             $stmt_hist->bind_param("s", $eid);
             $stmt_hist->execute();
             $stmt_hist->close();

             $stmt_quiz = $con->prepare("DELETE FROM `quiz` WHERE eid = ?");
             $stmt_quiz->bind_param("s", $eid);
             $stmt_quiz->execute(); 

             if ($stmt_quiz->affected_rows > 0) {
                 $con->commit(); 
             } else {
                 $con->rollback(); 
                 throw new Exception("Quiz with EID $eid not found.");
             }
             $stmt_quiz->close(); 

        } catch (mysqli_sql_exception $exception) { 
            $con->rollback(); 
            error_log("Error removing quiz $eid: " . $exception->getMessage()); 
            header("location:dashboard.php?q=5&error=1");
            exit;
        }
        header("location:dashboard.php?q=5&removed=1"); 
        exit;
    }

    if ($action == 'addquiz' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name']);
        $total = filter_input(INPUT_POST, 'total', FILTER_VALIDATE_INT, ["options" => ["min_range"=>1]]);
        $sahi = filter_input(INPUT_POST, 'right', FILTER_VALIDATE_INT, ["options" => ["min_range"=>0]]);
        $wrong = filter_input(INPUT_POST, 'wrong', FILTER_VALIDATE_INT, ["options" => ["min_range"=>0]]);

        if (empty($name) || $total === false || $sahi === false || $wrong === false) {
            header("location:dashboard.php?q=4&error=invalid_input");
            exit;
        }

        $eid = uniqid('qz_');

        $stmt = $con->prepare("INSERT INTO `quiz` (eid, title, sahi, wrong, total, date) VALUES (?, ?, ?, ?, ?, NOW())");
         $stmt->bind_param("ssiii", $eid, $name, $sahi, $wrong, $total); 

        if ($stmt->execute()) { 
            header("location:dashboard.php?q=4&step=2&eid=$eid&n=$total"); 
            exit;
        } else {
            error_log("Error adding quiz details: " . $stmt->error); 
            header("location:dashboard.php?q=4&error=add_details"); 
            exit;
        }
        $stmt->close(); 
    }
    if ($action == 'addqns' && isset($_GET['eid'], $_GET['n']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $eid = $_GET['eid']; /* source: 118 */
        $n = (int)$_GET['n']; /* source: 119 */
        $ch = 4; // Assuming 4 choices /* source: 119 */

        // Validate parameters
        if ($n <= 0) {
            header("location:dashboard.php?q=4&error=invalid_input"); exit;
        }

        $con->begin_transaction(); /* source: 119 */
        try {
            // Prepare statements outside the loop /* source: 120, 121 */
            $stmt_qns = $con->prepare("INSERT INTO `questions` (eid, qid, qns, choice, sn) VALUES (?, ?, ?, ?, ?)");
            $stmt_opt = $con->prepare("INSERT INTO `options` (qid, `option`, optionid) VALUES (?, ?, ?)");
            $stmt_ans = $con->prepare("INSERT INTO `answer` (qid, ansid) VALUES (?, ?)");

            for ($i = 1; $i <= $n; $i++) { /* source: 122 */
                // --- Question Data ---
                $qns = trim($_POST['qns' . $i]); /* source: 122 */
                $qid = uniqid('qn_' . $i . '_'); /* source: 122 */
                $sn = $i; /* source: 123 */

                if (empty($qns)) { /* source: 123 */
                    throw new Exception("Question text for question #$i cannot be empty.");
                }
                $stmt_qns->bind_param("sssis", $eid, $qid, $qns, $ch, $sn); /* source: 124 */
                if (!$stmt_qns->execute()) { /* source: 124 */
                    throw new Exception("Error inserting question #$i: " . $stmt_qns->error); /* source: 125 */
                }

                // --- Options and Answer Data ---
                $options_data = [];
                $option_letters = ['a', 'b', 'c', 'd']; /* source: 126 */
                $correct_choice_key = $_POST['ans' . $i] ?? null; /* source: 132 */
                $correct_ans_id = null;

                if ($correct_choice_key === null || !in_array($correct_choice_key, $option_letters)) { /* source: 133 */
                     throw new Exception("A valid correct answer must be selected for question #$i.");
                 }

                for ($j = 1; $j <= $ch; $j++) { /* source: 127 */
                    $opt_text_key = $i . $j;
                    $opt_text = trim($_POST[$opt_text_key] ?? ''); /* source: 127 */
                    $opt_id = uniqid('opt_' . $i . '_' . $j . '_'); /* source: 128 */
                    $current_option_letter = $option_letters[$j-1];

                    if (empty($opt_text)) { /* source: 129 */
                        throw new Exception("Option text for question #$i, option " . strtoupper($current_option_letter) . " cannot be empty."); /* source: 129 */
                    }

                    $options_data[$current_option_letter] = $opt_id; // Store letter -> id mapping

                    $stmt_opt->bind_param("sss", $qid, $opt_text, $opt_id); /* source: 130 */
                    if (!$stmt_opt->execute()) { /* source: 131 */
                        throw new Exception("Error inserting option " . strtoupper($current_option_letter) . " for question #$i: " . $stmt_opt->error); /* source: 131 */
                    }

                    if ($current_option_letter == $correct_choice_key) { /* source: 132 */
                        $correct_ans_id = $opt_id; /* source: 134 */
                    }
                }

                 // Ensure correct answer ID was found (should always be true if validation passes)
                 if ($correct_ans_id === null) {
                     throw new Exception("Correct answer ID could not be determined for question #$i.");
                 }


                // Insert the correct answer reference /* source: 134 */
                $stmt_ans->bind_param("ss", $qid, $correct_ans_id);
                if (!$stmt_ans->execute()) { /* source: 134 */
                    throw new Exception("Error inserting answer for question #$i: " . $stmt_ans->error); /* source: 134 */
                }
            } // End loop for questions

            $con->commit(); /* source: 135 */

            // Close statements /* source: 135 */
            $stmt_qns->close();
            $stmt_opt->close();
            $stmt_ans->close();

            header("location:dashboard.php?q=0&quiz_added=1"); /* source: 136 */
            exit;

        } catch (Exception $e) { /* source: 136 */
            $con->rollback(); /* source: 136 */
            // Close statements if they were opened /* source: 137 */
            if (isset($stmt_qns) && $stmt_qns instanceof mysqli_stmt) $stmt_qns->close();
            if (isset($stmt_opt) && $stmt_opt instanceof mysqli_stmt) $stmt_opt->close();
            if (isset($stmt_ans) && $stmt_ans instanceof mysqli_stmt) $stmt_ans->close();

            error_log("Error adding questions for quiz $eid: " . $e->getMessage()); /* source: 138 */
            // Pass error message via session flash /* source: 138 */
            $_SESSION['add_question_error'] = $e->getMessage();
            header("location:dashboard.php?q=4&step=2&eid=$eid&n=$n&error=add_qns"); /* source: 139 */
            exit;
        }
    }

} // End Admin Only Actions


// --- Fallback Redirect --- /* source: 182 */
if (!$isUser && !$isAdmin) {
    header("Location: login.php");
} elseif ($isUser && !$isAdmin && $action && !in_array($action, ['quiz', 'quizre'])) { // User trying non-user action
     header("Location: welcome.php?q=1&error=forbidden");
} elseif ($isAdmin && !$isUser && $action && !in_array($action, ['duser', 'rmquiz', 'addquiz', 'addqns'])) { // Admin trying non-admin action
     header("Location: dashboard.php?q=0&error=invalid_action");
} elseif ($isUser && !$action) {
     header("Location: welcome.php?q=1");
} elseif ($isAdmin && !$action) {
     header("Location: dashboard.php?q=0");
} else { // Default redirect if somehow missed
    header("Location: index.php");
}
exit;

$con->close(); // Should not be reached
?>