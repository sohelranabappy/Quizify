<?php
require_once 'database.php';
session_start();


if (!isset($_SESSION['user_email'])) {
    header("location: login.php");
    exit;
}

$user_name = htmlspecialchars($_SESSION['user_name']);
$user_email = $_SESSION['user_email'];


$q = isset($_GET['q']) ? $_GET['q'] : 1;

$allowed_q_strings = ['quiz', 'result', 'history', 'ranking'];
if (!is_numeric($q) && !in_array($q, $allowed_q_strings)) {
    $q = 1;
}
if (is_numeric($q)) {
    $q = (int)$q;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <title>Welcome, <?php echo $user_name; ?> - Online Quiz System</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"> 
    <link rel="stylesheet" href="style.css"> 
</head>
<body class="bg-light"> <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm sticky-top"> 
        <div class="container">
            <a class="navbar-brand logo-font" href="welcome.php?q=1">QuizApp</a> 
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavUser" aria-controls="navbarNavUser" aria-expanded="false" aria-label="Toggle navigation"> 
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavUser"> 
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($q == 1) ? 'active' : ''; ?>" href="welcome.php?q=1"><i class="bi bi-house-door-fill"></i> Home</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($q == 2 || $q == 'history') ? 'active' : ''; ?>" href="welcome.php?q=2"><i class="bi bi-clock-history"></i> History</a> 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($q == 3 || $q == 'ranking') ? 'active' : ''; ?>" href="welcome.php?q=3"><i class="bi bi-trophy-fill"></i> Ranking</a> 
                    </li>
                     </ul>
                <ul class="navbar-nav ms-auto"> 
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownUser" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> <?php echo $user_name; ?> 
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownUser"> 
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li> 
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">

            <?php
                if ($q == 1) {

                    echo '<div class="card panel">';
                    echo '<div class="card-header panel-title">Available Quizzes</div>';
                    echo '<div class="card-body panel-body">';
                    $stmt_quiz_list = $con->prepare(
                        "SELECT q.eid, q.title, q.total, q.sahi, q.wrong, h.score
                         FROM `quiz` q
                         LEFT JOIN `history` h ON q.eid = h.eid AND h.email = ?
                         ORDER BY q.date DESC"
                    );
                    $stmt_quiz_list->bind_param("s", $user_email);
                    $stmt_quiz_list->execute();
                    $result_quiz_list = $stmt_quiz_list->get_result();
                    if ($result_quiz_list->num_rows > 0) {
                        echo '<div class="table-responsive">';
                        echo '<table class="table table-striped table-hover align-middle">';
                        echo '<thead><tr><th>#</th><th>Topic</th><th>Questions</th><th>Max Marks</th><th>Status</th><th>Action</th></tr></thead>';
                        echo '<tbody>';
                        $c = 1;
                        while ($row = $result_quiz_list->fetch_assoc()) {
                            $eid = htmlspecialchars($row['eid']);
                            $title = htmlspecialchars($row['title']);
                            $total = (int)$row['total'];
                            $sahi = (int)$row['sahi'];
                            $max_marks = $total * $sahi;
                            $history_score = $row['score'];
                            echo '<tr>';
                            echo '<td>' . $c++ . '</td>';
                            echo '<td>' . $title . '</td>';
                            echo '<td>' . $total . '</td>';
                            echo '<td>' . $max_marks . '</td>';
                            if ($history_score !== null) {
                                echo '<td><span class="badge bg-success"><i class="bi bi-check-circle-fill"></i> Completed</span></td>';
                                echo '<td><a href="update.php?q=quizre&step=25&eid=' . $eid . '&t=' . $total . '" class="btn btn-warning btn-sm" onclick="return confirm(\'Are you sure you want to restart this quiz? Your previous score will be removed.\');"><i class="bi bi-arrow-clockwise"></i> Restart</a></td>';
                            } else {
                                echo '<td><span class="badge bg-secondary">Not Started</span></td>';
                                echo '<td><a href="welcome.php?q=quiz&step=2&eid=' . $eid . '&n=1&t=' . $total . '" class="btn btn-primary btn-sm"><i class="bi bi-play-fill"></i> Start</a></td>';
                            }
                            echo '</tr>';
                        }
                        echo '</tbody></table></div>';
                    } else {
                        echo '<p class="text-center text-muted">No quizzes available at the moment. Check back later!</p>';
                    }
                    echo '</div></div>';
                    $stmt_quiz_list->close();

                }

                elseif ($q == 'quiz' && isset($_GET['step']) && $_GET['step'] == 2 && isset($_GET['eid']) && isset($_GET['n']) && isset($_GET['t'])) {
                      $eid = $_GET['eid'];
                      $sn = (int)$_GET['n'];
                      $total = (int)$_GET['t'];
                      $stmt_ques = $con->prepare("SELECT qid, qns FROM `questions` WHERE eid = ? AND sn = ?");
                      $stmt_ques->bind_param("si", $eid, $sn);
                      $stmt_ques->execute();
                      $result_ques = $stmt_ques->get_result();
                      if ($result_ques->num_rows == 1) {
                          $question = $result_ques->fetch_assoc();
                          $qid = $question['qid'];
                          $qns = nl2br(htmlspecialchars($question['qns']));
                          $stmt_opts = $con->prepare("SELECT optionid, `option` FROM `options` WHERE qid = ? ORDER BY RAND()");
                          $stmt_opts->bind_param("s", $qid);
                          $stmt_opts->execute();
                          $result_opts = $stmt_opts->get_result();
                          if ($result_opts->num_rows > 0) {
                               echo '<div class="card quiz-question-box shadow-sm">';
                               echo '<div class="card-header bg-light">';
                               echo '<h5 class="mb-0">Question ' . $sn . ' of ' . $total . '</h5>';
                               echo '</div>';
                               echo '<div class="card-body">';
                               echo '<p class="lead question-text">' . $qns . '</p>';
                               echo '<hr>';
                               echo '<form action="update.php?q=quiz&step=2&eid=' . $eid . '&n=' . $sn . '&t=' . $total . '&qid=' . $qid . '" method="POST" class="mt-3" id="quizForm" novalidate>';
                               while ($option = $result_opts->fetch_assoc()) {
                                   $optionid = htmlspecialchars($option['optionid']);
                                   $option_text = htmlspecialchars($option['option']);
                                   echo '<div class="form-check mb-3 fs-5">';
                                   echo '<input class="form-check-input" type="radio" name="ans" id="opt_' . $optionid . '" value="' . $optionid . '" required>';
                                   echo '<label class="form-check-label" for="opt_' . $optionid . '">' . $option_text . '</label>';
                                   echo '</div>';
                               }
                               echo '<div class="invalid-feedback d-block" id="radioError" style="display: none;">Please select an answer.</div>';
                               echo '<hr class="my-4">';
                               echo '<button type="submit" class="btn btn-success btn-lg"><i class="bi bi-check-lg"></i> Submit Answer</button>';
                               echo '</form>';
                               echo '</div>';
                               echo '</div>';
                          } else {
                               echo '<div class="alert alert-danger">Error: No options found for this question.</div>';
                              echo '<a href="welcome.php?q=1" class="btn btn-secondary mt-3">Back to Quiz List</a>';
                          }
                          $stmt_opts->close();
                      } else {
                           echo '<div class="alert alert-danger">Error: Question not found or invalid parameters.</div>';
                           echo '<a href="welcome.php?q=1" class="btn btn-secondary mt-3">Back to Quiz List</a>';
                      }
                      $stmt_ques->close();
                }

                elseif ($q == 'result' && isset($_GET['eid'])) {
                    $eid = $_GET['eid'];

                    $stmt_hist = $con->prepare("SELECT score, level, sahi, wrong FROM `history` WHERE email = ? AND eid = ?");
                    $stmt_hist->bind_param("ss", $user_email, $eid);
                    $stmt_hist->execute(); 
                    $result_hist = $stmt_hist->get_result();

                    if ($result_hist->num_rows == 1) { 
                        $history = $result_hist->fetch_assoc();
                        $score = $history['score']; 
                        $level = $history['level']; 
                        $sahi_count = $history['sahi'];
                        $wrong_count = $history['wrong'];

                        
                        $overall_score = 0;
                        $stmt_rank = $con->prepare("SELECT score FROM `rank` WHERE email = ?"); 
                        
                        $stmt_rank->bind_param("s", $user_email); 
                        
                        $stmt_rank->execute(); 
                        
                        $result_rank = $stmt_rank->get_result(); 
                        
                        if ($result_rank->num_rows == 1) {
                            $overall_score = (int)$result_rank->fetch_assoc()['score']; 
                            
                        }
                        $stmt_rank->close(); 
                        

                        
                        
                        $quiz_title = "Quiz";
                        $stmt_title = $con->prepare("SELECT title FROM `quiz` WHERE eid = ?");
                        $stmt_title->bind_param("s", $eid); 
                        
                        $stmt_title->execute(); 
                        
                        $res_title = $stmt_title->get_result();
                        if ($res_title->num_rows == 1) {
                            
                            $quiz_title = htmlspecialchars($res_title->fetch_assoc()['title']);
                        }
                        $stmt_title->close();
                        

                        echo '<div class="card panel result-card">';
                        
                        echo '<div class="card-header panel-title text-center bg-primary-subtle"><h4 class="mb-0">Result: ' . $quiz_title . '</h4></div>';
                        
                        echo '<div class="card-body panel-body">';
                        
                        echo '<div class="table-responsive">';
                        echo '<table class="table table-bordered table-striped result-table fs-5">';
                        echo '<tbody>';
                        echo '<tr><td class="w-50"><i class="bi bi-list-ol text-primary"></i> Total Questions Attempted</td><td>' . $level . '</td></tr>';
                        echo '<tr class="table-success"><td><i class="bi bi-check-circle-fill text-success"></i> Correct Answers</td><td>' . $sahi_count . '</td></tr>'; 
                        echo '<tr class="table-danger"><td><i class="bi bi-x-circle-fill text-danger"></i> Wrong Answers</td><td>' . $wrong_count . '</td></tr>'; 
                        echo '<tr class="table-info fw-bold"><td><i class="bi bi-star-fill text-info"></i> Score for this Quiz</td><td>' . $score . '</td></tr>'; 
                        echo '<tr class="table-secondary fw-bold"><td><i class="bi bi-bar-chart-line-fill text-secondary"></i> Overall Score</td><td>' . $overall_score . '</td></tr>';
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '<div class="text-center mt-4">';
                        echo '<a href="welcome.php?q=1" class="btn btn-primary me-2"><i class="bi bi-house-door"></i> Back to Home</a>'; 
                        echo '<a href="welcome.php?q=2" class="btn btn-secondary"><i class="bi bi-clock-history"></i> View History</a>'; 
                        echo '</div>';
                        echo '</div></div>';
                    } else {
                        echo '<div class="alert alert-danger">Error: Could not retrieve result for this quiz. Did you complete it?</div>'; 
                        echo '<a href="welcome.php?q=1" class="btn btn-secondary">Back to Quiz List</a>';
                    }
                    $stmt_hist->close();
                }

                elseif ($q == 2 || $q == 'history') {
                    echo '<div class="card panel">';
                    echo '<div class="card-header panel-title"><i class="bi bi-clock-history"></i> Quiz Attempt History</div>';
                    echo '<div class="card-body panel-body">';
                    $stmt_hist_list = $con->prepare(
                        "SELECT h.eid, h.score, h.level, h.sahi, h.wrong, h.date, q.title
                         FROM `history` h
                         JOIN `quiz` q ON h.eid = q.eid
                         WHERE h.email = ?
                         ORDER BY h.date DESC"
                    );
                    $stmt_hist_list->bind_param("s", $user_email);
                    $stmt_hist_list->execute();
                    $result_hist_list = $stmt_hist_list->get_result();

                    if ($result_hist_list->num_rows > 0) {
                        echo '<div class="table-responsive">';
                        echo '<table class="table table-striped table-hover">';
                        echo '<thead><tr><th>#</th><th>Quiz Title</th><th>Attempted</th><th>Correct</th><th>Wrong</th><th>Score</th><th>Date</th></tr></thead>';
                        echo '<tbody>';
                        $c = 1;
                        while ($row = $result_hist_list->fetch_assoc()) {
                            $title = htmlspecialchars($row['title']);
                            $level = htmlspecialchars($row['level']);
                            $sahi = htmlspecialchars($row['sahi']);
                            $wrong = htmlspecialchars($row['wrong']);
                            $score = htmlspecialchars($row['score']);
                            $date = date("Y-m-d H:i", strtotime($row['date']));
                            echo '<tr>'; 
                            echo '<td>' . $c++ . '</td>';
                            echo '<td>' . $title . '</td>';
                            echo '<td>' . $level . '</td>';
                            echo '<td class="text-success">' . $sahi . '</td>';
                            echo '<td class="text-danger">' . $wrong . '</td>'; 
                            echo '<td class="fw-bold">' . $score . '</td>'; 
                            echo '<td>' . $date . '</td>'; 
                            echo '</tr>';
                        }
                        echo '</tbody></table></div>';
                    } else {
                        echo '<p class="text-center text-muted">You haven\'t attempted any quizzes yet.</p>'; 
                    }
                    echo '</div></div>';
                    $stmt_hist_list->close(); 
                }

                elseif ($q == 3 || $q == 'ranking') {
                    echo '<div class="card panel">';
                    echo '<div class="card-header panel-title"><i class="bi bi-trophy-fill"></i> Overall User Rankings</div>';
                    echo '<div class="card-body panel-body">';

                    $stmt_rank_list = $con->prepare(
                        "SELECT r.email, r.score, u.name
                         FROM `rank` r
                         JOIN `user` u ON r.email = u.email
                         ORDER BY r.score DESC, r.time ASC" 
                    );
                    $stmt_rank_list->execute(); 
                    $result_rank_list = $stmt_rank_list->get_result(); 

                    if ($result_rank_list->num_rows > 0) { 
                        echo '<div class="table-responsive">';
                        echo '<table class="table table-striped table-hover ranking-table">'; 
                        echo '<thead><tr><th>Rank</th><th>Name</th><th>Score</th></tr></thead>';
                        echo '<tbody>';
                        $c = 1;
                        while ($row = $result_rank_list->fetch_assoc()) { 
                            $rank = $c++;
                            $name = htmlspecialchars($row['name']);
                            $email = htmlspecialchars($row['email']);
                            $score = htmlspecialchars($row['score']);

                            $highlight_class = ($email == $user_email) ? 'table-info fw-bold current-user-rank' : '';

                            echo '<tr class="' . $highlight_class . '">'; 
                            echo '<td><span class="rank-badge">' . $rank . '</span></td>';
                            echo '<td>' . $name . '</td>';
                            echo '<td>' . $score . '</td>'; 
                            echo '</tr>';
                        }
                        echo '</tbody></table></div>'; 
                    } else {
                        echo '<p class="text-center text-muted">No ranking data available yet.</p>'; 
                    }
                    echo '</div></div>';
                    $stmt_rank_list->close();
                }

                 elseif ($q != 1 && $q != 'quiz' && $q != 'result' && $q != 2 && $q != 'history' && $q != 3 && $q != 'ranking') {
                    echo '<div class="alert alert-warning">Invalid section requested. Redirecting to home...</div>'; 
                    echo '<script>setTimeout(function(){ window.location.href = "welcome.php?q=1"; }, 2000);</script>'; 
                }

                ?>
            </div> </div> </div> <footer class="footer mt-auto py-3 bg-light border-top">
        <div class="container text-center">
            <span class="text-muted">Online Quiz System &copy; <?php echo date("Y"); ?></span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
     <script>

         if (window.history.replaceState) {
             let url = new URL(window.location.href);
             let paramsToRemove = ['registered', 'feedback_sent', 'error', 'rank_error'];
             let paramsChanged = false;
             paramsToRemove.forEach(param => {
                 if (url.searchParams.has(param)) {
                     url.searchParams.delete(param);
                     paramsChanged = true;
                 }
             });
              if (paramsChanged && url.searchParams.get('q') !== 'quiz') {
                 window.history.replaceState({ path: url.toString() }, '', url.toString());
             }
         }
        const quizForm = document.getElementById('quizForm');
        const radioError = document.getElementById('radioError');
        if (quizForm && radioError) {
            quizForm.addEventListener('submit', function(event) {
                const checkedRadio = quizForm.querySelector('input[name="ans"]:checked');
                if (!checkedRadio) {
                     event.preventDefault();
                     radioError.style.display = 'block';
                } else {
                     radioError.style.display = 'none';
                }
            });
        }
     </script>

</body>
</html>
<?php $con->close(); ?>